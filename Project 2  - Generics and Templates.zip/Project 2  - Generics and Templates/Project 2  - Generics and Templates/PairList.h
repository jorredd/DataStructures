#pragma once
#include "LinkedList.h"

class PairList : public LinkedList()
{
public:
	PairList();
	~PairList();
};

